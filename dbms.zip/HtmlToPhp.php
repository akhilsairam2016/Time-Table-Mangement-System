<?php
include('databaseconn.php');
include('addcourse.php');

$id=$_POST['id'];
$title=$_POST['title'];
$dept=$_POST['department'];
$ins="INSERT INTO course (course_id,course_title,dept_no) values('$id','$title','$dept')";

$run=mysqli_query($conn,$ins);

if($run){
	echo "<p align='center'> <font color=green> New data has been succesfully inserted</p>";
}else
{
	echo "<p align='center'> <font color=red> New data has NOT been inserted </p>";
    echo "<p align='center'> As there is already a course name with '$title' or a courseid with '$id'</p>";
}

?>
