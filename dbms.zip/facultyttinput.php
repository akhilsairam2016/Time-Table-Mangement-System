
<!DOCTYPE html>

	<head >
	 
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="description" content="Amrita University Timetable management">
                <meta name="keywords" content="timetable, management, generation">
                <meta author="">
                <link rel="stylesheet" href="assets/css/main.css" />
  		</head>
   <body class="is-preload">
    	
		<div  ><link rel="stylesheet" href="style.css">
		
			<header id="header">
				<a class="logo">Amrita University Timetable management</a>
				
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>
<div id="heading" ><h1>Timetable Management and Generation System</h1> 
</div>
		<nav  id ="menu">
			<ul class="links">
				<li ><a href="display.php" >Home</a></li>
				<li><a href="addfaculty.php">Add Faculty</a></li>
				<li><a href="addcourse.php">Add Course</a></li>
				<li><a href="Classttinput.php">View class Timetable</a></li>
				<li><a href="Facultyttinput.php">View Faculty TimeTable</a></li>
				<li><a href="deleteclassttinput.php">Drop Period</a></li>
			</ul>
			</nav>


	
				<h2 style="text-align: center;padding-top: 10px;"  >FACULTY TIME TABLE</h2>
			</div>
			<form action="facultyttdisplay.php" method="POST">
			<div style="float:left;padding: 30px;padding-left: 600px;">
			<select name="fname" required="">
		  <option value="" disabled selected>Faculty Name</option>
		  <?php

			include("databaseconn.php");

			$query="SELECT * FROM 	faculty";

	$runsql=mysqli_query($conn,$query);

		 if (mysqli_num_rows($runsql) > 0) {
		while($result=mysqli_fetch_assoc($runsql))
		{

			?>
		  
		  <option value="<?php echo $result['facultyname'] ?>"><?php echo $result['facultyname'] ?></option>
		  
		  <?php }} ?>
		  </select></div>

<div style="padding:  5px 46%;"><button type="submit">submit</button></div>
</form>

<div class="footer"><link rel="stylesheet" type="text/css" href="style.css"><footer>
      Amrita CSE Dept, Copyright &copy; 2018
    </footer></div>
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

    </div>
	
</body>
</html>

