<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
  	        <meta name="viewport" content="width=device-width">
		<meta name="description" content="Amrita University Timetable management">
                <meta name="keywords" content="timetable, management, generation">
  	        <meta name="author" content="Amrit Gupta">
		<link rel="stylesheet" href="assets/css/main.css" />

</head>

	<body class="is-preload">
    	
		<div  ><link rel="stylesheet" href="style.css">
		
			<header id="header">
				<a class="logo">Amrita University Timetable management</a>
				
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>
<div id="heading" ><h1>Timetable Management and Generation System</h1> 
</div>
		<nav  id ="menu">
			<ul class="links">
				<li ><a href="display.php" >Home</a></li>
				<li><a href="addfaculty.php">Add Faculty</a></li>
				<li><a href="addcourse.php">Add Course</a></li>
				<li><a href="Classttinput.php">View class Timetable</a></li>
				<li><a href="Facultyttinput.php">View Faculty TimeTable</a></li>
				<li><a href="deleteclassttinput.php">Drop Period</a></li>
			</ul>
			</nav>
		
      			<div ><link rel="stylesheet" type="text/css" href="style.css">
	        <div style="padding-top:10px;text-align: center; "><h2>Add Faculty Details</h2></div>
	        <form action="HtmltoPhpFaculty.php" method="POST">
	          
	         <div style="float: left; padding: 20px;padding-left: 360px;"><input type="text" name="fname" placeholder="Enter Faculty Name" required=""></div>
<div style="float: left; padding: 20px;">
		<select name="dept" required="">
		  <option value="" disabled selected>Select Department</option>
		  <option value="1">CSE</option>
		  <option value="2">ECE</option>
		  <option value="3">MECH</option>
		  <option value="4">EEE</option>
		  <option value="5">MATHS</option>
		  <option value="6">CIR</option>
		  <option value="7">CHY</option>
		</select>
	</div>
<div style="float: left; padding: 20px;"">
		<select name="course" required="">
		  <option value="" disabled selected>Select Course</option>
		 
		 <?php
		 	include("databaseconn.php");

			$query="SELECT * FROM course";

			$runsql=mysqli_query($conn,$query);

		 
		while($result=mysqli_fetch_assoc($runsql))
		{

			?>
		  <option value="<?php echo $result['course_id'] ?>"><?php echo $result['course_id'] ?></option>
		  
		  <?php } ?>

		</select>
		</div>
		<div style="padding:5px 45%">
        	  <button type="submit" class="button_1">Submit</button>
	        </div>
	        </form>
	      </div>
    	</section>
	<div class="footer"><link rel="stylesheet" type="text/css" href="style.css"><footer>
      Amrita CSE Dept, Copyright &copy; 2018
    </footer></div>
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

</body>
</html>
