


<html>
<?php


include("databaseconn.php");
include("deleteclassttinput.php");
$id=$_POST["classid"];
$day=$_POST["day"];
$cour=$_POST["course"];
$p=$_POST["period"];


$ins="DELETE FROM classtt where class_id='$id'and day='$day' and period='$p'and course='$cour'";

$run=mysqli_query($conn,$ins);
$checksql="select  * From faculty WHERE course_id='$cour'";
$res=mysqli_query($conn,$checksql);
$result=mysqli_fetch_assoc($res);
if($run){
	echo "<p align='center'> <font color=green>  Data has been been succesfully deleted</p>";
	
}else
{
	echo "<p align='center'> <font color=red>  Data has NOT been deleted as there is a no period  alloted</p>";
}



#while($result=mysqli_fetch_assoc($res))
#		{
					
					

#		}
		
$in="delete from facultytt where facultyname='{$result['facultyname']}'and course='$cour'and period='$p'and day='$day'";
$re=mysqli_query($conn,$in);

?>

</html>