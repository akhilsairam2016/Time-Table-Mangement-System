


<html>
<?php


include("databaseconn.php");
include("display.php");
$id=$_POST["classid"];
$day=$_POST["day"];
$cour=$_POST["course"];
$p=$_POST["period"];


$ins="INSERT INTO classtt (class_id,day,period,course) values('$id','$day','$p','$cour')";

$run=mysqli_query($conn,$ins);
$checksql="select  * From faculty WHERE course_id='$cour'";
$res=mysqli_query($conn,$checksql);
$result=mysqli_fetch_assoc($res);
if($run){
	echo "<p align='center'> <font color=green> New data has been succesfully inserted</p>";
}else
{
	echo "<p align='center'> <font color=red> New data has NOT been inserted as there is a period already alloted</p>";
    echo "<p align='center'> Mrs/Ms {$result['facultyname']}  has already been alloted a period on $day</p>";
}



#while($result=mysqli_fetch_assoc($res))
#		{
					
					

#		}
		
$in="Insert into facultytt (facultyname,course,period,day) values ('{$result['facultyname']}','$cour','$p','$day')";
$re=mysqli_query($conn,$in);

?>

</html>