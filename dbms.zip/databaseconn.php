

<?php

$sever  = "localhost";

$username ="root";

$password ="";

$database="time table";

$conn=mysqli_connect($sever,$username,$password,$database);



?>