<?php


include("databaseconn.php");
include("addfaculty.php");
$nam=$_POST['fname'];
$dept=$_POST["dept"];
$cour=$_POST['course'];


$ins="INSERT INTO Faculty (facultyname,course_id,dept_no) values('$nam','$cour','$dept')";

$run=mysqli_query($conn,$ins);

if($run){
	echo "<p align='center'> <font color=green> New Faculty details has been added succesfully inserted.</p>";
}else
{
	echo "<p align='center'> <font color=red> New Faculty details has NOT been inserted. </p>";
    echo "<p align='center'> As there is already a Faculty name with '$nam'. Please add surname.</p>";
}


?>