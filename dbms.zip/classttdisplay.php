<!DOCTYPE html>
<html>
	<head >
	 
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="description" content="Amrita University Timetable management">
                <meta name="keywords" content="timetable, management, generation">
                <meta author="">
                <link rel="stylesheet" href="assets/css/main.css" />
  		</head>
   <body class="is-preload">
    	
		<div  ><link rel="stylesheet" href="style.css">
		
			<header id="header">
				<a class="logo">Amrita University Timetable management</a>
				
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>
<div id="heading" ><h1>Timetable Management and Generation System</h1> 
</div>
		<nav  id ="menu">
			<ul class="links">
				<li ><a href="display.php" >Home</a></li>
				<li><a href="addfaculty.php">Add Faculty</a></li>
				<li><a href="addcourse.php">Add Course</a></li>
				
			    <li><a href="Classttinput.php">View class Timetable</a></li>
			    <li><a href="Facultyttinput.php">View Faculty TimeTable</a></li>
			    <li><a href="deleteclassttinput.php">Drop Period</a></li>
			</ul>
			</nav>
		


	<div class="table-wrapper">
										<table class="alt">									
<div style="font-family: sans-serif;">
   <?php

   include("databaseconn.php");

	$id=$_POST["classid"];
?>

												<tr>
													<div style="text-align: center;font-size: 30px;font-family:serif;"><?php echo "$id's Timetable"   ?></div>
													
												</tr>	
									
<?php
	echo"	<thead>
												<tr>
													<th>day</th>
													<th>Period 1</th>
													<th>Period 2</th>
													<th>Period 3</th>
													<th>Period 4</th>
													<th>Period 5</th>
													<th>Period 6</th>
													
												</tr>
											</thead>
	";

 $sql="Select * from classtt where class_id='$id' and day='Monday'";
	$res=mysqli_query($conn,$sql);
$row =mysqli_fetch_assoc($res);
	echo "<tr> <td>Monday</td>";
	for($i=1;$i<=6;$i++){
	$res1=mysqli_query($conn,"Select * from classtt where class_id='$id' and day='Monday' and period=$i");
    if(mysqli_num_rows($res1)) {echo "<td>".$row['course']."</td>";}
	else{echo "<td>".'empty'."</td>";}

	}
echo	"</tr>";




 $sql="Select * from classtt where class_id='$id' and day='Tuesday'";
	$res=mysqli_query($conn,$sql);
   $row =mysqli_fetch_assoc($res);
	echo "<tr> <td>Tuesday</td>";
	for($i=1;$i<=6;$i++){
	$res1=mysqli_query($conn,"Select * from classtt where class_id='$id' and day='Tuesday' and period=$i");
    if(mysqli_num_rows($res1)) {echo "<td>".$row['course']."</td>";}
	else{echo "<td>".'empty'."</td>";}

	}
echo	"</tr>";

 $sql="Select * from classtt where class_id='$id' and day='Wednesday'";
	$res=mysqli_query($conn,$sql);
    $row =mysqli_fetch_assoc($res);
	echo "<tr> <td>Wednesday</td>";
	for($i=1;$i<=6;$i++){
	$res1=mysqli_query($conn,"Select * from classtt where class_id='$id' and day='Wednesday' and period=$i");
    if(mysqli_num_rows($res1)) {echo "<td>".$row['course']."</td>";}
	else{echo "<td>".'empty'."</td>";}

	}
echo	"</tr>";

  	$sql="Select * from classtt where class_id='$id' and day='Thursday'";
	$res=mysqli_query($conn,$sql);
	$row =mysqli_fetch_assoc($res);
	echo "<tr> <td>Thursday</td>";
	for($i=1;$i<=6;$i++){
	$res1=mysqli_query($conn,"Select * from classtt where class_id='$id' and day='Thursday' and period=$i");
    if(mysqli_num_rows($res1)) {echo "<td>".$row['course']."</td>";}
	else{echo "<td>".'empty'."</td>";}

	}
echo	"</tr>";


    $sql="Select * from classtt where class_id='$id' and day='Friday'";
	$res=mysqli_query($conn,$sql);
	$row =mysqli_fetch_assoc($res);
	echo "<tr> <td>Friday</td>";
	for($i=1;$i<=6;$i++){
	$res1=mysqli_query($conn,"Select * from classtt where class_id='$id' and day='Friday' and period=$i");
    if(mysqli_num_rows($res1)) {echo "<td>".$row['course']."</td>";}
	else{echo "<td>".'empty'."</td>";}

	}
echo	"</tr>";	?>
	</table></div>

			
	<div class="footer"><link rel="stylesheet" type="text/css" href="style.css"><footer>
      Amrita CSE Dept, Copyright &copy; 2018
    </footer></div>
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
</div>
      </div></body></html>
	