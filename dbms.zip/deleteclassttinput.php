<!DOCTYPE html>
<html>
	<head >
	 
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="description" content="Amrita University Timetable management">
                <meta name="keywords" content="timetable, management, generation">
                <meta author="">
                <link rel="stylesheet" href="assets/css/main.css" />
  		</head>
   <body class="is-preload">
    	
		<div  ><link rel="stylesheet" href="style.css">
		
			<header id="header">
				<a class="logo">Amrita University Timetable management</a>
				
				<nav>
					<a href="#menu">Menu</a>
				</nav>
			</header>
<div id="heading" ><h1>Timetable Management and Generation System</h1> 
</div>

		<nav  id ="menu">
			<ul class="links">
				<li ><a href="display.php" >Home</a></li>
				<li><a href="addfaculty.php">Add Faculty</a></li>
				<li><a href="addcourse.php">Add Course</a></li>
				<li><a href="Classttinput.php">View class Timetable</a></li>
				<li><a href="Facultyttinput.php">View Faculty TimeTable</a></li>
				<li><a href="deleteclassttinput.php">Drop Period</a></li>
			</ul>
			</nav>
			
		
	<form  style="" href="#" action="deleteclasstt.php" method= "POST">
	<div style="float:left;padding: 50px;padding-left: 200px;">
	        <select name="classid" required="">
		  <option value="" disabled selected>Class id</option>
		  <?php

			include("databaseconn.php");

			$query="SELECT * FROM class";

	$runsql=mysqli_query($conn,$query);

		 if (mysqli_num_rows($runsql) > 0) {
		while($result=mysqli_fetch_assoc($runsql))
		{

			?>
		  
		  <option value="<?php echo $result['class_id'] ?>"><?php echo $result['class_id'] ?></option>
		  
		  <?php }} ?>

		</select>
</div>
<div style="float:left;padding: 50px;">
		<select name="day" required="">
		  <option value="" disabled selected>DAY</option>
		  <option value="Monday">Monday</option>
		  <option value="Tuesday">Tuesday</option>
		  <option value="Wednesday">Wednesday</option>
		  <option value="Thursday">Thursday</option>
		  <option value="Friday">Friday</option>
		</select>
</div>
<div style="float:left;padding: 50px;">
		<select name="period" required="">
		  <option value="" disabled selected>Period</option>
		  <option value=1>I</option>
		  <option value=2>II</option>
		  <option value=3>III</option>
		  <option value=4>IV</option>
		  <option value=5>V</option>
		  <option value=6>VI</option>
		</select>
</div>
<div style="float:left; padding: 50px;">
		<select name="course" required="">
		  <option value="" disabled selected>Select Course</option>
		
		<?php

		//include_once 'databaseconn.php';
		
		$query="SELECT * FROM course";

		$runsql=mysqli_query($conn,$query);

		while($result=mysqli_fetch_assoc($runsql))
		{
			?>
		
		  <option value="<?php echo $result['course_id'] ?>"><?php echo $result['course_id'] ?></option>
		
		<?php  }  ?>
		
		</select>
		</div>
	
		<div style="padding: 5px 43%">
		<button type="submit" class="button_1" required >Submit</button>
	        </div></form>

<div class="footer"><link rel="stylesheet" type="text/css" href="style.css"><footer>
      Amrita CSE Dept, Copyright &copy; 2018
    </footer></div>
    <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

    </div>
	
</body>
</html>
